# Existing support API

Starting revision for the developer exercise. The app already serves team totals at GET /api/summary and has five passing tests. HEAD initially returns 405.

Use Node.js 22 or later. In the extracted folder, record the local Git baseline for LoKiEnte.

```powershell
git init
git add .
git -c user.name=Example -c user.email=example@localhost -c commit.gpgsign=false commit -m "Baseline: existing GET summary API"
node --test
```

Open this project in the managed LoKiEnte session and enter the request in Kilo’s `shadow-chat`.

> Extend the existing Node.js server with HEAD /api/summary. Return the same status, Content-Type and byte Content-Length as GET, with an empty body. Preserve GET's JSON contract and /health. Only the summary route should advertise GET, HEAD. Extract the shared response into src/summary-response.cjs. Add loopback HTTP integration tests, run the existing suite and request independent security and integration reviews. No new dependencies or external network calls.

[Developer walkthrough and completed source](https://github.com/mauricehuschke/LoKiEnte/tree/main/examples/support-board)
