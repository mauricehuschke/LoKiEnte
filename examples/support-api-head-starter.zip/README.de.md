# Bestehende Support-API

Ausgangsstand für den Entwicklerauftrag. Die App liefert eine Teamübersicht über GET /api/summary und besitzt fünf bestandene Tests. HEAD liefert zunächst 405.

Mit Node.js ab Version 22 im entpackten Ordner ausführen. Für LoKiEnte zuerst den lokalen Git-Ausgangsstand festhalten.

```powershell
git init
git add .
git -c user.name=Example -c user.email=example@localhost -c commit.gpgsign=false commit -m "Baseline: existing GET summary API"
node --test
```

Öffne dieses Projekt in deiner verwalteten LoKiEnte-Sitzung und gib den Auftrag in Kilos `shadow-chat` ein.

> Erweitere den bestehenden Node.js-Server um HEAD /api/summary. Status, Content-Type und Content-Length in Bytes müssen mit GET übereinstimmen. Der Body bleibt leer. Erhalte den JSON-Vertrag von GET und das Verhalten von /health. Nur die Summary-Route soll GET, HEAD ankündigen. Extrahiere die gemeinsame Antwort nach src/summary-response.cjs. Ergänze HTTP-Integrationstests auf Loopback, führe die bestehende Testsuite aus und fordere unabhängige Sicherheits- und Integrationsreviews an. Keine neuen Abhängigkeiten oder externen Netzwerkzugriffe.

[Entwicklertour und fertiger Quellcode](https://github.com/mauricehuschke/LoKiEnte/tree/main/examples/support-board)
